module.exports = {
  domain: "https://haqixstore.private.pterohost.my.id/", // Ubah Domain Panel !!!
  port: "2000" // Ubah Port Panel !!!
};